# SolarMan App - Financing Tab Edition

This version includes:
- A placeholder tab for loan options from GoodLeap, Sunlight, and PSCCU
- Clickable PSCCU preferred link
- Sample monthly payment ranges

## Setup
Deploy with Streamlit and no API keys are required for this version.
