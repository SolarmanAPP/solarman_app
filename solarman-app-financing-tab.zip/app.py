import streamlit as st
import os

st.set_page_config(page_title="SolarMan - Financing Options", layout="wide")

tabs = st.tabs(["🏠 Home", "📊 Estimate", "💰 Financing Options"])

with tabs[0]:
    st.title("🔆 SolarMan")
    st.header("Welcome!")
    st.write("Use this app to estimate your solar potential and explore financing.")

with tabs[1]:
    st.header("📊 Estimate (Coming from your earlier zip)")
    st.info("This section will show your real-time Solar API estimates and panel count. Already implemented in previous version.")

with tabs[2]:
    st.header("💰 Financing Options")
    st.subheader("Explore solar loan partners and estimate monthly payments")

    st.markdown("""
### 📌 Loan Examples

| Loan Provider | Term | Rate | Est. Monthly for $25,000 |
|---------------|------|------|---------------------------|
| GoodLeap      | 25 yr | 4.99% | ~$145/mo                |
| Sunlight Financial | 20 yr | 5.49% | ~$165/mo         |
| [🌟 **PSCCU Solar Financing Options (Preferred)**](https://www.psccu.org/loans/solar-loans.html) | 15 yr | 4.24% | ~$187/mo |

---

📎 Select one of the options above to begin a credit check or contact your installer for help.

📩 More real-time financing tools will be added as partners approve your API access.
    """)

    st.success("✅ Once you're approved by any provider, we’ll auto-connect quotes to live loan options here.")
