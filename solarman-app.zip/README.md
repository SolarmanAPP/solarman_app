# SolarMan App ☀️

A Streamlit app to estimate solar system cost and monthly payments based on roof size.

### Features
- System size estimator
- Pricing calculator (Seattle rates)
- Monthly payment option
- Company contact info

Built by Northern Pacific Electric.
