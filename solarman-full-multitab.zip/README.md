SolarMan full app with multi-tabs: Quote + Financing + Hive Builder
