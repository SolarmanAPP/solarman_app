SolarMan app with PDF quote export functionality
